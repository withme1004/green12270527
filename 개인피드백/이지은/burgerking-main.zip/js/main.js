var swiper = new Swiper(".mySwiper", {
  speed: 1000,
  autoplay: {
    delay: 2500,
    disableOnInteraction: false,
  },
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },
});
let popup = document.querySelector("#popup");
let con = document.querySelector(".ad_con_01");
con.onclick = function () {
  popup.style.visibility = "visible";
};

popup.querySelector(".close").onclick = function (e) {
  e.preventDefault();
  popup.style.visibility = "hidden";
};
